<footer class="page-footer">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Thanks for visiting Jing's Chatroom!</h5>
                <p class="grey-text text-lighten-4">This is made using HTML, CSS, PHP, XML and styled using MaterializeCSS!</p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            Made for HTTP5203 Assignment 3
            <a class="grey-text text-lighten-4 right" href="#!">© 2019 Jing Cheng</a>
        </div>
    </div>
</footer>